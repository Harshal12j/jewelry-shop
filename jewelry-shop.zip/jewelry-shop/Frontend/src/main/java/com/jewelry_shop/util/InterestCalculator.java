package com.jewelry_shop.util;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class InterestCalculator {

    public static double calculateInterest(double amountBorrowed, double interestRate, LocalDate startDate, LocalDate endDate) {
        long months = ChronoUnit.MONTHS.between(startDate, endDate);
        return amountBorrowed * (interestRate / 100) * months;
    }
}
