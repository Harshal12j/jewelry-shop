package com.jewelry_shop.controller;

import com.jewelry_shop.MainApp;
import com.jewelry_shop.model.Customer;
import com.jewelry_shop.service.CustomerService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class MainWindowController {

    @FXML
    private TextField fullNameField;
    @FXML
    private TextField mobileNumberField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField aadharCardField;
    @FXML
    private TextField amountBorrowedField;
    @FXML
    private DatePicker dateOfBorrowingPicker;
    @FXML
    private TextField interestRateField;
    @FXML
    private TextField typeOfOrnamentField;
    @FXML
    private TextField calculatedInterestField;
    @FXML
    private TextField pictureField;
    @FXML
    private TextField digitalSignatureField;
    @FXML
    private TextField searchField;
    @FXML
    private Button searchButton;
    @FXML
    private Button saveButton;
    @FXML
    private Button listCustomersButton;
    @FXML
    private Button uploadPictureButton;
    @FXML
    private Button uploadSignatureButton;
    @FXML
    private BorderPane mainBorderPane;

    private MainApp mainApp;
    private CustomerService customerService;

    public MainWindowController() {
        this.customerService = new CustomerService();
    }

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    private void initialize() {
        saveButton.setOnAction(event -> saveCustomer());
        searchButton.setOnAction(event -> searchCustomer());
        listCustomersButton.setOnAction(event -> showCustomerList());
        uploadPictureButton.setOnAction(event -> uploadPicture());
        uploadSignatureButton.setOnAction(event -> uploadSignature());
    }

    private void saveCustomer() {
        try {
            Customer customer = new Customer(
                    fullNameField.getText(),
                    mobileNumberField.getText(),
                    addressField.getText(),
                    aadharCardField.getText(),
                    Double.parseDouble(amountBorrowedField.getText()),
                    java.sql.Date.valueOf(dateOfBorrowingPicker.getValue()),
                    pictureField.getText(),
                    digitalSignatureField.getText(),
                    Double.parseDouble(interestRateField.getText()),
                    typeOfOrnamentField.getText(),
                    Double.parseDouble(calculatedInterestField.getText())
            );
            customerService.createCustomer(customer);
            showAlert(Alert.AlertType.INFORMATION, "Customer Saved", "Customer has been saved successfully.");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Save Error", "Error occurred while saving customer.");
        }
    }

    private void searchCustomer() {
        String fullName = searchField.getText();
        try {
            List<Customer> customers = customerService.searchCustomerByName(fullName);
            if (customers.isEmpty()) {
                showAlert(Alert.AlertType.INFORMATION, "Search Result", "No customer found with the name: " + fullName);
            } else {
                // Display search results
                for (Customer customer : customers) {
                    showCustomerDetails(customer);
                }
            }
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Search Error", "Error occurred while searching for customer.");
        }
    }

    private void showCustomerDetails(Customer customer) {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/com/jewelry_shop/view/CustomerDetails.fxml"));
            BorderPane customerDetailsPane = loader.load();

            CustomerDetailsController controller = loader.getController();
            controller.setCustomer(customer);

            mainBorderPane.setCenter(customerDetailsPane);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showCustomerList() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/com/jewelry_shop/view/CustomerList.fxml"));
            BorderPane customerListPane = loader.load();

            CustomerListController controller = loader.getController();
            controller.setCustomerService(customerService);

            mainBorderPane.setCenter(customerListPane);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void uploadPicture() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Upload Picture");
        File file = fileChooser.showOpenDialog(mainApp.getPrimaryStage());
        if (file != null) {
            pictureField.setText(file.getAbsolutePath());
        }
    }

    private void uploadSignature() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Upload Digital Signature");
        File file = fileChooser.showOpenDialog(mainApp.getPrimaryStage());
        if (file != null) {
            digitalSignatureField.setText(file.getAbsolutePath());
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
