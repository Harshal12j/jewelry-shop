package com.jewelry_shop.controller;

import com.jewelry_shop.model.Customer;
import com.jewelry_shop.service.CustomerService;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.util.List;

public class CustomerListController {

    @FXML
    private TableView<Customer> customerTableView;
    @FXML
    private TableColumn<Customer, String> fullNameColumn;
    @FXML
    private TableColumn<Customer, String> mobileNumberColumn;

    private CustomerService customerService;

    @FXML

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
        loadCustomerData();
    }

    private void loadCustomerData() {
        List<Customer> customers = customerService.getAllCustomers();
        customerTableView.getItems().setAll(customers);
    }
}
