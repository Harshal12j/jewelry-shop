package com.jewelry_shop.service;

import com.jewelry_shop.model.Customer;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.hc.client5.http.HttpResponseException;
import org.apache.hc.client5.http.fluent.Request;
import org.apache.hc.core5.http.ContentType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;

public class CustomerService {

    private static final String BASE_URL = "http://localhost:8080/api/customers";
    private static final Logger logger = LogManager.getLogger(CustomerService.class);
    private final Gson gson;

    public CustomerService() {
        this.gson = new Gson();
    }

    public List<Customer> getAllCustomers() {
        try {
            String response = Request.get(BASE_URL)
                    .execute()
                    .returnContent()
                    .asString();
            Type customerListType = new TypeToken<List<Customer>>() {}.getType();
            return gson.fromJson(response, customerListType);
        } catch (IOException e) {
            logger.error("Error fetching customers", e);
            return Collections.emptyList();
        }
    }

    public void createCustomer(Customer customer) throws IOException {
        String json = gson.toJson(customer);
        try {
            Request.post(BASE_URL)
                    .bodyString(json, ContentType.APPLICATION_JSON)
                    .execute()
                    .discardContent();
        } catch (IOException e) {
            logger.error("Error creating customer", e);
            throw e;
        }
    }

    public double calculateInterest(double amountBorrowed, double interestRate, int months) {
        return amountBorrowed * (interestRate / 100) * months;
    }

    public List<Customer> searchCustomerByName(String fullName) throws IOException {
        List<Customer> customers = Collections.emptyList();
        try {
            String encodedName = URLEncoder.encode(fullName, StandardCharsets.UTF_8.toString()).replace("+", "%20");
            String url = BASE_URL + "/byname/" + encodedName;
            logger.info("Request URL: " + url);

            String jsonResponse = Request.get(url)
                    .execute()
                    .returnContent()
                    .asString();
            logger.info("Response: " + jsonResponse);

            Type customerListType = new TypeToken<List<Customer>>() {}.getType();
            customers = gson.fromJson(jsonResponse, customerListType);
        } catch (HttpResponseException e) {
            if (e.getStatusCode() == 404) {
                logger.warn("Customer not found: 404 - " + e.getMessage());
            } else {
                logger.error("HttpResponseException: " + e.getStatusCode() + " - " + e.getMessage(), e);
                throw e;
            }
        } catch (IOException e) {
            logger.error("IOException: " + e.getMessage(), e);
            throw e;
        }
        return customers;
    }
}
