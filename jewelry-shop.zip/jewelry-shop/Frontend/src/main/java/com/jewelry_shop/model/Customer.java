package com.jewelry_shop.model;



import java.util.Date;

public class Customer {

    private Long id;
    private String fullName;
    private String mobileNumber;
    private String address;
    private String aadharCard;
    private Double amountBorrowed;
    private Date dateOfBorrowing;
    private String picture;
    private String digitalSignature;
    private Double interestRate;
    private String typeOfOrnament;
    private Double calculatedInterest;

    public Customer(String text, String mobileNumberFieldText, String addressFieldText, String aadharCardFieldText, double v, java.sql.Date date, String pictureFieldText, String digitalSignatureFieldText, double parseDouble, String typeOfOrnamentFieldText, double aDouble){
        super();
    }

    public Customer(Long id, String fullName, String mobileNumber, String address, String aadharCard, Double amountBorrowed, Date dateOfBorrowing, String picture, String digitalSignature, Double interestRate, String typeOfOrnament, Double calculatedInterest) {
        this.id = id;
        this.fullName = fullName;
        this.mobileNumber = mobileNumber;
        this.address = address;
        this.aadharCard = aadharCard;
        this.amountBorrowed = amountBorrowed;
        this.dateOfBorrowing = dateOfBorrowing;
        this.picture = picture;
        this.digitalSignature = digitalSignature;
        this.interestRate = interestRate;
        this.typeOfOrnament = typeOfOrnament;
        this.calculatedInterest = calculatedInterest;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAadharCard() {
        return aadharCard;
    }

    public void setAadharCard(String aadharCard) {
        this.aadharCard = aadharCard;
    }

    public Double getAmountBorrowed() {
        return amountBorrowed;
    }

    public void setAmountBorrowed(Double amountBorrowed) {
        this.amountBorrowed = amountBorrowed;
    }

    public Date getDateOfBorrowing() {
        return dateOfBorrowing;
    }

    public void setDateOfBorrowing(Date dateOfBorrowing) {
        this.dateOfBorrowing = dateOfBorrowing;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getDigitalSignature() {
        return digitalSignature;
    }

    public void setDigitalSignature(String digitalSignature) {
        this.digitalSignature = digitalSignature;
    }

    public Double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    public String getTypeOfOrnament() {
        return typeOfOrnament;
    }

    public void setTypeOfOrnament(String typeOfOrnament) {
        this.typeOfOrnament = typeOfOrnament;
    }

    public Double getCalculatedInterest() {
        return calculatedInterest;
    }

    public void setCalculatedInterest(Double calculatedInterest) {
        this.calculatedInterest = calculatedInterest;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", fullName='" + fullName + '\'' +
                ", mobileNumber=" + mobileNumber +
                ", address='" + address + '\'' +
                ", aadharCard='" + aadharCard + '\'' +
                ", amountBorrowed=" + amountBorrowed +
                ", dateOfBorrowing=" + dateOfBorrowing +
                ", picture='" + picture + '\'' +
                ", digitalSignature='" + digitalSignature + '\'' +
                ", interestRate=" + interestRate +
                ", typeOfOrnament='" + typeOfOrnament + '\'' +
                ", calculatedInterest=" + calculatedInterest +
                '}';
    }
}
