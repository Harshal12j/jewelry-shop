package com.jewelry_shop;

import com.jewelry_shop.controller.MainWindowController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.InputStream;

public class MainApp extends Application {

    private Stage primaryStage;
    private BorderPane mainLayout;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Jewelry Shop Management System");

        initMainLayout();
    }

    public void initMainLayout() {
        try {
            FXMLLoader loader = new FXMLLoader();
            InputStream fxmlStream = MainApp.class.getResourceAsStream("/fxml/MainWindow.fxml");

            if (fxmlStream == null) {
                throw new IOException("FXML file not found");
            }

            mainLayout = loader.load(fxmlStream);

            Scene scene = new Scene(mainLayout);
            primaryStage.setScene(scene);
            primaryStage.show();

            MainWindowController controller = loader.getController();
            controller.setMainApp(this);

        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
