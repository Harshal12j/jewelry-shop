package com.jewelry_shop.controller;

import com.jewelry_shop.model.Customer;
import com.jewelry_shop.util.InterestCalculator;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class CustomerDetailsController {

    @FXML
    private Label fullNameLabel;
    @FXML
    private Label mobileNumberLabel;
    @FXML
    private Label addressLabel;
    @FXML
    private Label aadharCardLabel;
    @FXML
    private Label amountBorrowedLabel;
    @FXML
    private Label dateOfBorrowingLabel;
    @FXML
    private Label interestRateLabel;
    @FXML
    private Label typeOfOrnamentLabel;
    @FXML
    private Label calculatedInterestLabel;

    private Customer customer;

    public void setCustomer(Customer customer) {
        this.customer = customer;
        updateCustomerDetails();
    }

    private void updateCustomerDetails() {
        if (customer != null) {
            fullNameLabel.setText(customer.getFullName());
            mobileNumberLabel.setText(customer.getMobileNumber());
            addressLabel.setText(customer.getAddress());
            aadharCardLabel.setText(customer.getAadharCard());
            amountBorrowedLabel.setText(String.format("%.2f", customer.getAmountBorrowed()));
            dateOfBorrowingLabel.setText(customer.getDateOfBorrowing().toString());
            interestRateLabel.setText(String.format("%.2f", customer.getInterestRate()));
            typeOfOrnamentLabel.setText(customer.getTypeOfOrnament());

            // Calculate the interest
            Date dateOfBorrowing = customer.getDateOfBorrowing();
            LocalDate borrowingDate = convertToLocalDate(dateOfBorrowing);
            LocalDate currentDate = LocalDate.now();
            double calculatedInterest = InterestCalculator.calculateInterest(
                    customer.getAmountBorrowed(),
                    customer.getInterestRate(),
                    borrowingDate,
                    currentDate
            );
            calculatedInterestLabel.setText(String.format("%.2f", calculatedInterest));
        } else {
            clearCustomerDetails();
        }
    }

    private void clearCustomerDetails() {
        fullNameLabel.setText("");
        mobileNumberLabel.setText("");
        addressLabel.setText("");
        aadharCardLabel.setText("");
        amountBorrowedLabel.setText("");
        dateOfBorrowingLabel.setText("");
        interestRateLabel.setText("");
        typeOfOrnamentLabel.setText("");
        calculatedInterestLabel.setText("");
    }

    private LocalDate convertToLocalDate(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
}
