package com.jewelryshop.jewelry_shop.controller;

import com.jewelryshop.jewelry_shop.model.Customer;
import com.jewelryshop.jewelry_shop.service.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private static final Logger log = LoggerFactory.getLogger(CustomerController.class);

    @Autowired
    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        log.debug("Received request to create customer: {}", customer);
        try {
            Customer savedCustomer = customerService.saveCustomer(customer);
            log.debug("Customer created successfully: {}", savedCustomer);
            return ResponseEntity.ok(savedCustomer);
        } catch (Exception e) {
            log.error("Error creating customer", e);
            return ResponseEntity.status(500).build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable Long id) {
        Customer customer = customerService.getCustomerById(id);
        if (customer != null) {
            double interest = customerService.calculateInterest(customer);
            customer.setCalculatedInterest(interest);
            return ResponseEntity.ok(customer);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomers() {
        List<Customer> customers = customerService.getAllCustomers();
        return ResponseEntity.ok(customers);
    }

    @GetMapping("/byname/{name}")
    public ResponseEntity<List<Customer>> getCustomerByName(@PathVariable String name) {
        System.out.println("Received request to search customers by name: " + name);

        // Decode the name if necessary
        name = URLDecoder.decode(name, StandardCharsets.UTF_8);

        System.out.println("Decoded name: " + name);

        List<Customer> customers = customerService.findByName(name);
        if (customers.isEmpty()) {
            System.out.println("No customers found with name: " + name);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable Long id, @RequestBody Customer customerDetails) {
        Customer updatedCustomer = customerService.updateCustomer(id, customerDetails);
        if (updatedCustomer != null) {
            return ResponseEntity.ok(updatedCustomer);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        boolean isDeleted = customerService.deleteCustomer(id);
        if (isDeleted) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
