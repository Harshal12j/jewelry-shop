package com.jewelryshop.jewelry_shop.service;

import com.jewelryshop.jewelry_shop.model.Customer;
import com.jewelryshop.jewelry_shop.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public Customer getCustomerById(Long id) {
        Optional<Customer> customer = customerRepository.findById(id);
        return customer.orElse(null);
    }

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public double calculateInterest(Customer customer) {
        LocalDate today = LocalDate.now();
        LocalDate borrowingDate = Instant.ofEpochMilli(customer.getDateOfBorrowing().getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        long daysBetween = ChronoUnit.DAYS.between(borrowingDate, today);
        double interest = customer.getAmountBorrowed() * customer.getInterestRate() * daysBetween / 365 / 100;
        return interest;
    }

    public Customer updateCustomer(Long id, Customer customerDetails) {
        Optional<Customer> customerOptional = customerRepository.findById(id);

        if (customerOptional.isPresent()) {
            Customer customer = customerOptional.get();
            customer.setFullName(customerDetails.getFullName());
            customer.setMobileNumber(customerDetails.getMobileNumber());
            customer.setAddress(customerDetails.getAddress());
            customer.setAadharCard(customerDetails.getAadharCard());
            customer.setAmountBorrowed(customerDetails.getAmountBorrowed());
            customer.setDateOfBorrowing(customerDetails.getDateOfBorrowing());
            customer.setPicture(customerDetails.getPicture());
            customer.setDigitalSignature(customerDetails.getDigitalSignature());
            customer.setInterestRate(customerDetails.getInterestRate());
            customer.setTypeOfOrnament(customerDetails.getTypeOfOrnament());
            return customerRepository.save(customer);
        } else {
            return null;
        }
    }

    public boolean deleteCustomer(Long id) {
        Optional<Customer> customerOptional = customerRepository.findById(id);

        if (customerOptional.isPresent()) {
            customerRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
    public List<Customer> getCustomerByName(String name) {
        return customerRepository.findByFullName(name);
    }

    public List<Customer> findByName(String name) {
        return customerRepository.findByFullName(name);
    }
}
