package com.jewelryshop.jewelry_shop.model;


import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;

import java.util.Date;

@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullName;
    private String mobileNumber;
    private String address;
    private String aadharCard;
    private Double amountBorrowed;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MMM d, yyyy, hh:mm:ss a")
    private Date dateOfBorrowing;
    private String picture;
    private String digitalSignature;
    private Double interestRate;
    @Column(name = "type_of_ornaments", nullable = false)
    private String typeOfOrnament;
    @Transient
    private double calculatedInterest;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAadharCard() {
        return aadharCard;
    }

    public void setAadharCard(String aadharCard) {
        this.aadharCard = aadharCard;
    }

    public Double getAmountBorrowed() {
        return amountBorrowed;
    }

    public void setAmountBorrowed(Double amountBorrowed) {
        this.amountBorrowed = amountBorrowed;
    }

    public Date getDateOfBorrowing() {
        return dateOfBorrowing;
    }

    public void setDateOfBorrowing(Date dateOfBorrowing) {
        this.dateOfBorrowing = dateOfBorrowing;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getDigitalSignature() {
        return digitalSignature;
    }

    public void setDigitalSignature(String digitalSignature) {
        this.digitalSignature = digitalSignature;
    }

    public Double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    public String getTypeOfOrnament() {
        return typeOfOrnament;
    }

    public void setTypeOfOrnament(String typeOfOrnament) {
        this.typeOfOrnament = typeOfOrnament;
    }

    public double getCalculatedInterest() {
        return calculatedInterest;
    }

    public void setCalculatedInterest(double calculateInterest) {
        this.calculatedInterest = calculateInterest;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", fullName='" + fullName + '\'' +
                ", mobileNumber='" + mobileNumber + '\'' +
                ", address='" + address + '\'' +
                ", aadharCard='" + aadharCard + '\'' +
                ", amountBorrowed=" + amountBorrowed +
                ", dateOfBorrowing=" + dateOfBorrowing +
                ", picture='" + picture + '\'' +
                ", digitalSignature='" + digitalSignature + '\'' +
                ", interestRate=" + interestRate +
                ", typeOfOrnament='" + typeOfOrnament + '\'' +
                ", calculatedInterest=" + calculatedInterest +
                '}';
    }
}
